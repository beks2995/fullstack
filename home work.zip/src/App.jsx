import React from 'react'
import axios from 'axios'

const App = () => {
    const addProd = (e) => {
        e.preventDefault()
        axios({
            method: "post",
            url: "http://localhost:8080/product",
            headers: {
                "Content-Type": "application/json"
            },
            data: {
                "id": 1,
                "name": "iphone",
                "description": "lorem ipsum dhsajdnsdvbcjsad",
                "price": 20000
              }
        })
    }
    return (
        <div>
            <form onSubmit={addProd}>
                <h2>Добавление товара</h2>
                <label>
                    Название
                    <input type="text" />
                </label>
                <label>
                    Описание
                    <textarea name="" id=""></textarea>
                </label>
                <label>
                    цена
                    <input type="number" />
                </label>
                <button type="submit">Добавить</button>
            </form>
        </div>
    )
}

export default App