const express = require('express')
const bodyParser = require('body-parser')
const fs = require('fs')
const app = express()
const pathToFile = './server/product.json'
const cors = require('cors')

app.use(cors())
// const corsOpt = {
//     origin: process.env.CORS_ALLOW_ORIGIN || '*', // this work well to configure origin url in the server
//     methods: ['GET', 'PUT', 'POST', 'DELETE', 'OPTIONS'], // to works well with web app, OPTIONS is required
//     allowedHeaders: ['Content-Type', 'Authorization'] // allow json and token in the headers
// };
// app.use(cors(corsOpt)); // cors for all the routes of the application
// app.options('*', cors(corsOpt)); // automatic cors gen for HTTP verbs in all routes, This can be redundant but I kept to be sure that will always work.

// var corsOptions = {
//     origin: 'http://localhost:8080',
//     optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204
// }

// app.use(cors(corsOptions));

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
app.use(function (req, res, next) {
    res.set('Authorization', 'Bearer 2b4896d4d0c13c05b70e8fce92c7de0357a312fc4c3813741aeef19716533253c0e13c869da87bb4d213a9c17d4c95882b8a772e75cb027de81ef484a151baaff966e1f217945033ec5beee2ed23b78d0ef40640e230fac68be37d404f5dcf7ea56113496ac96369e7aba2655ddc6f80d97f01ddacb50280b84f12de58ee353c');
    next()
})

app.get('/product', (req, res) => {
  if (fs.existsSync(pathToFile)) {
    const data = fs.readFileSync(pathToFile)
    const products = JSON.parse(data)
    res.json(products)
  } else {
    res.json({
        success: false,
        reason: 'no data'
    })
  }

})
app.post('/product', (req, res) => {
  const newProduct = req.body
  let products = []
  if (fs.existsSync(pathToFile)) {
    const data = fs.readFileSync(pathToFile)
    products = JSON.parse(data)
  }

  products.push(newProduct)
  fs.writeFileSync(pathToFile, JSON.stringify(products, null, 2))

  res.json({ newProduct })
})

app.listen(8080)